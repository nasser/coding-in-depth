﻿using UnityEngine;

/**
 * Destroy GameObjects colliding with the GameObject this component is
 * attached to if they have a matching tag
 */
public class DestroyOtherOnCollision : MonoBehaviour
{
	// Only objects with this tag will be considered for collision
	// If blank, all collisions will be considered
	public string otherTag;

	void OnTriggerEnter2D(Collider2D otherCollider)
	{
		// if we collide with a GameObject with a tag matching `otherTag`
		if (otherCollider.gameObject.tag == otherTag)
		{
			// destroy it
			Destroy(otherCollider.gameObject);
		}
	}
}
